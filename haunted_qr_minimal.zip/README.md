# Haunted QR — Minimal Pages (No Nav)

Six standalone HTML pages, each with a haunted dark theme and your verse. No links, no buttons, no unlocking.

## Files
- clue1.html … clue6.html
- assets/style.css

## Use with Netlify
- Create a site and deploy this folder (drag-and-drop or from Git).
- Make QR codes directly to:
  - /clue1.html
  - /clue2.html
  - /clue3.html
  - /clue4.html
  - /clue5.html
  - /clue6.html